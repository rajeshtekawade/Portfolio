var typed = new Typed(".text", {
    strings: [ "Coding Enthusiast","Tech Learner", "Aspiring Developer","Data Science Learner"],
    typeSpeed: 100,
    backSpeed: 100,
    backDelay: 1000,
    loop: true
});
